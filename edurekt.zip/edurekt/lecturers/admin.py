from django.contrib import admin

from lecturers.models import Lecturer

admin.site.register(Lecturer)