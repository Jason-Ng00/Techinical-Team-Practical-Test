from django.contrib import admin

from rooms.models import Room

admin.site.register(Room)
