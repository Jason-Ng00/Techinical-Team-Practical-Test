from django.urls import path

from students.views import list_students

urlpatterns = [
    path('students', list_students)
]