from rest_framework import serializers

from cca.models import CCA
from students.models import Student

class StudentSerializer(serializers.ModelSerializer):
    ccas = serializers.PrimaryKeyRelatedField(queryset=CCA.objects.all(),many=True,read_only=False)

    class Meta:
        model = Student
        fields = ('matric_number', 'name', 'year', 'ccas')