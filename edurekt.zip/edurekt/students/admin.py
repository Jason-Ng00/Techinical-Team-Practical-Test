from django.contrib import admin

from students.models import Student, TakeModule, TakeCCA

admin.site.register(Student)
admin.site.register(TakeModule)
admin.site.register(TakeCCA)
