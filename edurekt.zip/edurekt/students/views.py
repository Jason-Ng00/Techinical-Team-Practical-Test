from rest_framework.decorators import api_view
from rest_framework.response import Response

from students.models import Student
from students.serializers import StudentSerializer

@api_view(['GET'])
def list_students(request):
    students = Student.objects.all()
    serializer = StudentSerializer(students)

    return Response({"students":serializer.data})
