from django.apps import AppConfig


class CcaConfig(AppConfig):
    name = 'cca'
