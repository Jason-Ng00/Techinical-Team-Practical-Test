from django.contrib import admin

from cca.models import CCA

admin.site.register(CCA)