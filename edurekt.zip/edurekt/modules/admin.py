from django.contrib import admin

from modules.models import Module

admin.site.register(Module)
