export class Room{
    code: string;
    name: string;
    address: string;
    max_capacity: number;
}