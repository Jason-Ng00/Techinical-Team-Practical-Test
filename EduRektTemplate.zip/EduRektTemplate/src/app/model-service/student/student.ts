export class Student {
    matriculation_number: string;
    name: string;
    year: number;
    course: string;
}